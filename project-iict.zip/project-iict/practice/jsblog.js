const card = document.getElementById('card');

card.addEventListener('click', () => {
  let text = [];
  text.innerHtml = window.alert("Blog not availble yet, stay tuned!");  
});